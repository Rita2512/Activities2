package com.rguz.activities2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SelectEmployee extends Activity implements View.OnClickListener {

    TextView loggedName;
    String nameDisplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_employee);
        loggedName = findViewById(R.id.textViewLoggedName);
        nameDisplay = getIntent().getExtras().getString("Send_Email");
        loggedName.setText(nameDisplay);

        TextView JP = findViewById(R.id.textViewJP);
        TextView JM = findViewById(R.id.textViewJM);
        TextView AG = findViewById(R.id.textViewAG);

        JP.setOnClickListener(this);
        JM.setOnClickListener(this);
        AG.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
     switch (v.getId()){
         case R.id.textViewJP:
             String[] emp1 = new String[]{"Juan Perez","JR analyst","70","31","70"};
             Intent sendJP = new Intent(this, Profile.class);
             Bundle bundle = new Bundle();
             bundle.putStringArray("Send_JP", emp1);
             sendJP.putExtras(bundle);
             startActivity(sendJP);
             break;
     }
        switch (v.getId()){
            case R.id.textViewJM:
                String[] emp1 = new String[]{"Julia Morales","Senior analyst","80","40","85"};
                Intent sendJP = new Intent(this, Profile.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("Send_JP", emp1);
                sendJP.putExtras(bundle);
                startActivity(sendJP);
                break;
        }

        switch (v.getId()){
            case R.id.textViewAG:
                String[] emp1 = new String[]{"Alfredo Guzman","Senior analyst II","95","55","90"};
                Intent sendJP = new Intent(this, Profile.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("Send_JP", emp1);
                sendJP.putExtras(bundle);
                startActivity(sendJP);
                break;
        }

     }
    }
